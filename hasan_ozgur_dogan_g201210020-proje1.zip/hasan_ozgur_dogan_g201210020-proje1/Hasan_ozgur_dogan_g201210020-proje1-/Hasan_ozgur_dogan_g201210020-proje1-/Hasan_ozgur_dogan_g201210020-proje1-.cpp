#include<iostream>

#include<fstream>

#include<locale.h>

#include <string>

using namespace std;
int main() {

    setlocale(LC_ALL, "turkish");
    int genel_secim = 0;

    //URUN.TXT DE YER ALICAK B�LG�LER::::
    int urun_islemi_secimi = 0;

    int urun_kodu;
    string urun_ad�;
    string urunun_ureticisi;
    int temin_suresi;
    string uretim_tarih;
    float fiyat;
    float ozel_fiyat;
    float kdv_orani;
    int stok_adedi;
    char cevap = 'h';

    //firma bilgilerini tutan bilgiler:::
    int firma_no;
    string firama_isimi;

    string firma_tel_no;
    string firma_Sorumlusu;
    string musteri_katagorisi; //(genel or �zel)
    string adres_bilgileri;
    int musteri_islmeleri_Secimi;
    char baska_msuteri_ekleme_istegi = 'h';

    //sipari� bilgielrini tutan bilgiler;	
    int firma_no_siparis;
    string siparisi_alan;
    int urun_kodu_siparis;
    int siparis_Adedi;
    string siparis_tarihi;
    int siparis_tutari;
    int siparis_no = 0;

    do { //men� i�lemerli i�in kula�cya se�enek sunuluyor
        cout << endl << "�r�n i�lemleri i�in 1:" << endl << "M��teri i�lermleri i�in 2:" << endl << "Sipari� i�lermelri i�in 3:" << endl << "cikis icin 4:";
        cin >> genel_secim;

        if (genel_secim == 1) //�r�n i�lemleri seene�ine y�nlendiriliyor...
        {
            do {
                cout << endl << "�r�n ekelem i�in 1:" << endl << "�r�n aramak i�in 2:" << endl << "�r�n listelemek i�in 3:" << endl << "�r�n d�zeltmek i�in 4:" << endl << "�r�n silmek i�in 5'e basiniz:" << endl << "Ana menu icin 6:" << endl;
                cin >> urun_islemi_secimi;

                if (urun_islemi_secimi == 1) //�R�M EKLEME....
                {

                    int urun_kodu_geici = 0;
                    do {
                        //gerkli doya okuma ve yazma nesnleri kurluyor...

                        ofstream dosyayaz;
                        dosyayaz.open("urun_bilgileri.txt", ios::app);
                        ifstream dosyaokuu;
                        ifstream dosayaokuuu;

                        int satir_sayisi = 0; // �r�n eklemedi teklik kontrolu i�in gerkli olan satir sayisini tanim�iyoruz...
                        dosayaokuuu.open("urun_bilgileri.txt");
                        dosyaokuu.open("urun_bilgileri.txt");
                        cout << "urun kodunu giriniz:";
                        cin >> urun_kodu_geici;
                        //var olan urun bilgileri.txt dosays�ndaki satir sayisini hesapliyor...
                        while (dosyaokuu >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                            satir_sayisi = satir_sayisi + 1;
                        }
                        //	cout <<endl<<"satirsaiyisi:"<< satir_sayisi << endl;
                        if (satir_sayisi == 0) //satir sayisinin 0 a e�it olma durumunda yap�lacak i�lem..
                        {
                            urun_kodu = urun_kodu_geici;
                            //	cout << "�r�n kodu:" << endl;			cin >> urun_kodu;
                            cout << "�r�n ad�:" << endl;
                            cin >> urun_ad�;
                            cout << "�r�n �reticisi" << endl;
                            cin >> urunun_ureticisi;
                            cout << "temin s�resi" << endl;
                            cin >> temin_suresi;
                            cout << "�retim tarihi" << endl;
                            cin >> uretim_tarih;
                            cout << "fiyat :" << endl;
                            cin >> fiyat;
                            cout << "�zel m��teri fiyat:" << endl;
                            cin >> ozel_fiyat;
                            cout << "kdv oran�:" << endl;
                            cin >> kdv_orani;
                            cout << "stok adedi:" << endl;
                            cin >> stok_adedi;
                            dosyayaz << urun_kodu << ' ' << urun_ad� << ' ' << urunun_ureticisi << ' ' << temin_suresi << ' ' << uretim_tarih << ' ' << fiyat << ' ' << ozel_fiyat << ' ' << kdv_orani << ' ' << stok_adedi << "\n";
                            cout << "�r�n ba�ariyla eklenmi�tir" << endl;
                            cout << "baska �r�n eklemek istiyor msunuz:e/h";
                            cin >> cevap;

                        }
                        if (satir_sayisi != 0) //satir sayisinin 0 dan farkli olma durumunda gerekli �r�n kodu kontrolu yap�l�yor eger girilen urun kodu zaten varsa program uyar� var�cek ve eklae yapmicak...

                        {
                            int kontrol = 1;
                            while (dosayaokuuu >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                if (urun_kodu_geici == urun_kodu) {
                                    kontrol = 0;
                                }
                            }
                            if (kontrol == 1) //eger ki kontrol degeri 0 dan farkl� ise �r�n eklem i�lermi yap�lcak...
                            {
                                urun_kodu = urun_kodu_geici;
                                //	cout << "�r�n kodu:" << endl;			cin >> urun_kodu;
                                cout << "�r�n ad���:" << endl;
                                cin >> urun_ad�;
                                cout << "�r�n �reticisi" << endl;
                                cin >> urunun_ureticisi;
                                cout << "temin s�resi" << endl;
                                cin >> temin_suresi;
                                cout << "�retim tarihi" << endl;
                                cin >> uretim_tarih;
                                cout << "fiyat :" << endl;
                                cin >> fiyat;
                                cout << "�zel m��teri fiyat:" << endl;
                                cin >> ozel_fiyat;
                                cout << "kdv oran�:" << endl;
                                cin >> kdv_orani;
                                cout << "stok adedi:" << endl;
                                cin >> stok_adedi;
                                dosyayaz << urun_kodu << ' ' << urun_ad� << ' ' << urunun_ureticisi << ' ' << temin_suresi << ' ' << uretim_tarih << ' ' << fiyat << ' ' << ozel_fiyat << ' ' << kdv_orani << ' ' << stok_adedi << "\n";
                                //ve al�nan degerler dosyan�n icine yaz�lcak...
                                cout << "�r�n ba�ariyla eklenmi�tir" << endl;
                                cout << "baska �r�n eklemek istiyor msunuz:e/h";
                                cin >> cevap;
                            }
                            else if (kontrol == 0) {
                                cout << "ekleme yapilamz..." << endl;
                                cout << "baska �r�n eklemek istiyor msunuz:e/h";
                                cin >> cevap;
                                satir_sayisi = 0;
                            }
                        }

                        dosyayaz.close();
                        dosyaokuu.close();
                        dosayaokuuu.close();

                    } while (!(cevap == 'h'));

                }
                else if (urun_islemi_secimi == 2) //�r�n aramak i�in
                {
                    int URUN_KODU;
                    cout << "durumunu ��renmek istedi�iniz �r�n�n kodunu giriniz:";
                    cin >> URUN_KODU; //kullan�c�dan �r�n sorgulamak icin urun kodu al�yotuz...ve dosyada ki her bir �r�n kodu ile al�nan kodu kar��la�t�r�yoruz...
                    ifstream dosyaoku("urun_bilgileri.txt");
                    while (dosyaoku >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                        if (URUN_KODU == urun_kodu) {
                            cout << endl << endl << "aranan �r�n bilgileri: " << endl;
                            cout << "urun adi: " << urun_ad� << endl;
                            cout << "�r�n �reticisi " << urunun_ureticisi;
                            cout << "fiyat:" << fiyat << endl;
                            cout << "stok adedi:" << stok_adedi << endl;

                        }
                        else //eger ki bi e�le�me yoksa b�y�e bi �r�n yoktur mesaj� vericek...
                        {
                            cout << endl << "b�yle bir �r�n kodu bulunmamaktad�r..." << endl;
                            break;

                        }
                    }
                }
                else if (urun_islemi_secimi == 3) //urunleri listeleme;
                {
                    cout << "�r�nler:";
                    ifstream dosyaoku("urun_bilgileri.txt");
                    //var olan b�t�n sat�rlar� belli bir d�zen i�inde lsiteleme i�lemi ...
                    while (dosyaoku >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                        cout << endl << endl << "�r�n�n kodu:" << urun_kodu << endl << "�r�n adi :" << urun_ad� << endl << "�r�n �reticisi:" << urunun_ureticisi << endl << "fiyat:" << fiyat << endl << "stok adedi : " << stok_adedi << endl;

                    }

                }
                else if (urun_islemi_secimi == 4) //urun d�zeltme;
             /* bu k�s�mda var olan urun_bilgileri.txt dosyas�ndan de�i�tirilecek olan �r�n kodu e�le�mesi yap�larak o �rn�n� farkl� bi if blo�u i�inde

                     yeni bir gecici dosya acarak onun i�in e�le�en �r�n kodu ad� alt�nda kullan�cadan yeni degerler alarak dosyaya kaydediyoruz...

                     else diyip ba�ka bir blok i�inde ise e�le�meyen verielri ayn� gecici dosya i�ine yaz�yoruz...

                     en sonunda ise var olan as�l urun_bilgierli.txt dosays�n� silip

                     yeni a�t���m�z gecici dosayn�n ad�n� urun_bilgierli.txt oalrak degistiiriyoruz...

                     */
                {
                    int degisicek_urnun_kodu;
                    cout << "de�i�tirmek istedi�iniz �r�n�n kodun giriniz:";
                    cin >> degisicek_urnun_kodu;

                    ifstream dosya_oku("urun_bilgileri.txt");
                    ofstream dosyayayaz2("urun_bilgileri_yenii.tmp", ios::app);
                    while (dosya_oku >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {

                        //	dosya_oku >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi;
                        if (degisicek_urnun_kodu == urun_kodu) {

                            cout << "degicek �r�n�n var olan bilhgileri";

                            cout << urun_kodu << endl << urun_ad� << endl << urunun_ureticisi << endl << temin_suresi << endl << uretim_tarih << endl << fiyat << endl << ozel_fiyat << endl << kdv_orani << endl << stok_adedi;

                            cout << "d�zenlemek istediginiz degerleri giriniz:";

                            cout << "urunun kodu:" << endl;
                            cin >> urun_kodu;
                            cout << "urunun adi:" << endl;
                            cin >> urun_ad�;
                            cout << "urunun �reticsi:" << endl;
                            cin >> urunun_ureticisi;
                            cout << "urunun temin s�resi:" << endl;
                            cin >> temin_suresi;
                            cout << "uretim tarihi:" << endl;
                            cin >> uretim_tarih;
                            cout << "fiyat biligsii giriniz:" << endl;
                            cin >> fiyat;
                            cout << " ozel fiyat giriniz:" << endl;
                            cin >> ozel_fiyat;
                            cout << "kdv oran�n� giriniz:" << endl;
                            cin >> kdv_orani;
                            cout << "stok adedi giriniz:" << endl;
                            cin >> stok_adedi;
                            dosyayayaz2 << urun_kodu << ' ' << urun_ad� << ' ' << urunun_ureticisi << ' ' << temin_suresi << ' ' << uretim_tarih << ' ' << fiyat << ' ' << ozel_fiyat << ' ' << kdv_orani << ' ' << stok_adedi << "\n";

                        }
                        else if (degisicek_urnun_kodu != urun_kodu) {
                            dosyayayaz2 << urun_kodu << ' ' << urun_ad� << ' ' << urunun_ureticisi << ' ' << temin_suresi << ' ' << uretim_tarih << ' ' << fiyat << ' ' << ozel_fiyat << ' ' << kdv_orani << ' ' << stok_adedi << "\n";
                        }

                        dosyayayaz2.close();

                    }
                    dosya_oku.close();

                    remove("urun_bilgileri.txt");
                    rename("urun_bilgileri_yenii.tmp", "urun_bilgileri.txt");

                }
                else if (urun_islemi_secimi == 5) // �r�n  silmek
             //gerekli dosya okuma ve silme nesnelerini a��yruz...
             //�r�n d�zeltme i�lemerlinde yapt�kalr�m�z�n     yap�yoruz fakat tek fark olarak il if i�indeki verielri yani e�le�en verielri gecici dosayn�n i�ine yazm�yoruz.
                {

                    int aranan_urunun_kodu;
                    cout << "silinicek urnunun kodu:";
                    cin >> aranan_urunun_kodu;
                    ifstream dosayayioku("urun_bilgileri.txt");
                    ofstream dosyayayazyeni("gecici.txt");
                    while (dosayayioku >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                        //	dosayayioku >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi;
                        if (aranan_urunun_kodu == urun_kodu) {
                            cout << "silinicek �rn�n ad�:" << urun_ad� << endl << "�reticisi" << urunun_ureticisi << endl << temin_suresi << endl << uretim_tarih << fiyat << endl << ozel_fiyat << endl << kdv_orani << endl << stok_adedi;
                        }
                        else {
                            dosyayayazyeni << urun_kodu << ' ' << urun_ad� << ' ' << urunun_ureticisi << ' ' << temin_suresi << ' ' << uretim_tarih << ' ' << fiyat << ' ' << ozel_fiyat << ' ' << kdv_orani << ' ' << stok_adedi << "\n";

                        }

                    }
                    dosayayioku.close();
                    dosyayayazyeni.close();
                    remove("urun_bilgileri.txt");
                    rename("gecici.txt", "urun_bilgileri.txt");

                }
            } while (urun_islemi_secimi != 6);

        }
        else if (genel_secim == 2) //m�steri i�lemleri egerki ana men�de kullan�c� 2 ye basarsa m��teri i�lemelri a��l�yor...
        {
            //m��teri i�lemleri i�inde de kendi i�inde bir men� a��l�yr gerekl i�lemler i�in....
            do {
                cout << endl << "m��teri eklemk i�in 1 basiniz:" <<
                    endl << "m��teri aramak i�in 2 basiniz:" <<
                    endl << "m��teri d�zlemtek i�in 3 basiniz:" <<
                    endl << "m�steri silmek i�in 4 basiniz:" <<
                    endl << "Ana menu icin 5' e basiniz:" << endl << endl;
                cin >> musteri_islmeleri_Secimi;

                if (musteri_islmeleri_Secimi == 1) //m��teri eklmem ....
                {
                    //ayn� i�lemler �r�n eklemek i�inde oldugu gibi kontrol yap�larak ekleniyor(tekili�i sa�lamak i�in)
                    //musteriler musteri katagorisine g�re s�n�flandr�l�yor...
                    do {

                        int geci_firma_no_teklik_icin;
                        cout << "eklmek istediginiz firma no giriniz:";
                        cin >> geci_firma_no_teklik_icin;
                        int satirsayisi_cari = 0;

                        ifstream dosyaokuCari_teklik;
                        dosyaokuCari_teklik.open("cari.txt");

                        while (dosyaokuCari_teklik >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {
                            satirsayisi_cari = satirsayisi_cari + 1;
                        }
                        dosyaokuCari_teklik.close();
                        ofstream dosyayaz3;
                        dosyayaz3.open("cari.txt", ios::app);
                        if (satirsayisi_cari == 0) {
                            firma_no = geci_firma_no_teklik_icin;
                            cout << "firma ismi:";
                            cin >> firama_isimi;
                            cout << "firma telefon";
                            cin >> firma_tel_no;
                            cout << "firma sorumlusu";
                            cin >> firma_Sorumlusu;
                            cout << "m��teri katagorisi (genel/�zel)";
                            cin >> musteri_katagorisi;
                            cout << "adres:";
                            cin >> adres_bilgileri;
                            dosyayaz3 << firma_no << ' ' << firama_isimi << ' ' << firma_tel_no << ' ' << firma_Sorumlusu << ' ' << musteri_katagorisi << ' ' << adres_bilgileri << endl;
                            cout << "m��teri ba�ariyla eklenmi�tir" << endl;

                        }
                        else if (satirsayisi_cari != 0) {
                            int kontrol_cari_icin = 1;
                            ifstream dosyaokuCari_teklik2;
                            dosyaokuCari_teklik2.open("cari.txt");
                            while (dosyaokuCari_teklik2 >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {
                                if (geci_firma_no_teklik_icin == firma_no) {
                                    kontrol_cari_icin = 0;

                                }

                            }

                            dosyaokuCari_teklik2.close();

                            if (kontrol_cari_icin == 1) {
                                firma_no = geci_firma_no_teklik_icin;
                                cout << "firma ismi:";
                                cin >> firama_isimi;
                                cout << "firma telefon";
                                cin >> firma_tel_no;
                                cout << "firma sorumlusu";
                                cin >> firma_Sorumlusu;
                                cout << "m��teri katagorisi (genel/ozel)";
                                cin >> musteri_katagorisi;
                                cout << "adres:";
                                cin >> adres_bilgileri;
                                dosyayaz3 << firma_no << ' ' << firama_isimi << ' ' << firma_tel_no << ' ' << firma_Sorumlusu << ' ' << musteri_katagorisi << ' ' << adres_bilgileri << endl;
                                cout << "m��teri ba�ariyla eklenmi�tir" << endl;

                            }
                            else if (kontrol_cari_icin == 0) {
                                cout << "m��teri eklenmez....";

                                satirsayisi_cari = 0;

                            }
                        }

                        dosyayaz3.close();
                        cout << endl << "ba�ka bir m��teri eklmek isityor musnuz: e/h";
                        cin >> baska_msuteri_ekleme_istegi;

                        cout << endl;

                    } while (!(baska_msuteri_ekleme_istegi == 'h'));

                }

                if (musteri_islmeleri_Secimi == 2) //m��teri arama 
                //var olan m��teriler aras�ndan girilern arancak m�steri nosu ile dosyadaki t�m m��teri nolar� e�l�icekeger uyu�ma olursa o sat�daki bilgiler ekrana ��kt� olarak verilicek
                {

                    int aranacak_musteri_numarsi;
                    int kontrol_for_musteri_varmi = 0;

                    cout << "l�tfen aratmak istediginiz m��teri numars� giriniz:";
                    cin >> aranacak_musteri_numarsi;
                    ifstream dosyaoku_urun_arama;
                    dosyaoku_urun_arama.open("cari.txt");
                    while (dosyaoku_urun_arama >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {
                        if (firma_no == aranacak_musteri_numarsi) {
                            cout << "firma no:" << firma_no << endl <<
                                "firma ismi:" << firama_isimi << endl <<
                                "firma tel no:" << firma_tel_no << endl <<
                                "firma_Sorumlusu:" << firma_Sorumlusu << endl <<
                                "m��teri katagorisi:" << musteri_katagorisi << endl <<
                                "adres bilgileri:" << adres_bilgileri << endl;
                            kontrol_for_musteri_varmi = 1;
                        }

                    }
                    dosyaoku_urun_arama.close();

                    if (kontrol_for_musteri_varmi == 0) {
                        cout << endl << "BU NUMARAYA A�T MUSTER� BULUNMAMAKTADIR..." << endl;
                    }

                }

                if (musteri_islmeleri_Secimi == 3) //m��teri d�zeltme
                //D�zeltielcek m��teri no su ile e�le�en m��teri if blo�una girerek yeni de�erler giriliyor ve yeni geicici dosayay kay�t yap�l�yor.
                {
                    int kontrol_duzeltme_teklik = 0;
                    int degicisek_musteri_no;
                    cout << "de�i�mesini istediginiz �r�n�n musteri no'sunu giriniz....";
                    cin >> degicisek_musteri_no;
                    int kontrol_msuteri_duzeltme = 1;

                    ofstream dosya_ya_yaz_musteri_duzltme("Cari_gecici.txt", ios::app);
                    ifstream dosyaOku_msuteri_duzeltme;
                    ifstream dosyaoku_musteri_duzeltme_teklik("cari.txt");
                    dosyaOku_msuteri_duzeltme.open("cari.txt");
                    int firma_no_gecici_kontrol;
                    while (dosyaOku_msuteri_duzeltme >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {

                        if (firma_no == degicisek_musteri_no) {

                            cout << "degisicek �r�n bilgileri...";
                            cout << endl << "firma ismi:" << firama_isimi << endl << "firma tel no:" << firma_tel_no << endl << "firma sorumulsu:" << firma_Sorumlusu <<
                                endl << "muster kotogorisi:" << musteri_katagorisi << endl << "adres bilgileri:" << adres_bilgileri << endl;

                            cout << "GUNCELME..." << endl;
                            cout << "firma kodu:" << endl;
                            cin >> firma_no_gecici_kontrol;

                            while (dosyaoku_musteri_duzeltme_teklik >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {
                                if (firma_no_gecici_kontrol == firma_no) {
                                    cout << "Bu no ya ait kay�t vard�r...." << endl;
                                    kontrol_duzeltme_teklik = 1;

                                }

                            }
                            dosyaoku_musteri_duzeltme_teklik.close();
                            if (kontrol_duzeltme_teklik == 0) {
                                firma_no = firma_no_gecici_kontrol;
                                cout << "firma ismi:" << endl;
                                cin >> firama_isimi;
                                cout << "firma tel no:" << endl;
                                cin >> firma_tel_no;
                                cout << "firma sorumlusu:" << endl;
                                cin >> firma_Sorumlusu;
                                cout << "musteri katogerisi:" << endl;
                                cin >> musteri_katagorisi;
                                cout << "adres bilgileri:" << endl;
                                cin >> adres_bilgileri;
                                dosya_ya_yaz_musteri_duzltme << firma_no << ' ' << firama_isimi << ' ' << firma_tel_no << ' ' << firma_Sorumlusu << ' ' << musteri_katagorisi << ' ' << adres_bilgileri << endl;
                            }

                        }
                        else if (firma_no != degicisek_musteri_no) {
                            dosya_ya_yaz_musteri_duzltme << firma_no << ' ' << firama_isimi << ' ' << firma_tel_no << ' ' << firma_Sorumlusu << ' ' << musteri_katagorisi << ' ' << adres_bilgileri << endl;

                        }

                    }
                    dosyaOku_msuteri_duzeltme.close();

                    dosya_ya_yaz_musteri_duzltme.close();
                    remove("cari.txt");
                    rename("Cari_gecici.txt", "cari.txt");

                }
                else if (musteri_islmeleri_Secimi == 4) //msuteri silme;

             //msuteri silmede yap�lan i�lem:al�nan m��teri no ile e�ele�en m��teri bilgiler d���ndaki bilgileri ge�ici bir txt dosyas�na atmak 
             //sonra �nceki dosyay� silerek yeni gecici dosyan�n isminini eski dosayn�n ismi yaparak silme i�lemi tamamlanacak. 

                {
                    int silincek_musterinin_nosu;
                    cout << "silmek istedihiniz musteri i�in no giriniz:";
                    cin >> silincek_musterinin_nosu;
                    ifstream Dosyaoku5;
                    Dosyaoku5.open("cari.txt");
                    ofstream Dosyayaz5("yeni_cari.txt", ios::app);
                    while (Dosyaoku5 >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {

                        if (silincek_musterinin_nosu == firma_no) {
                            cout << endl << "firma no" << firma_no;

                            cout << endl << "firma ismi:" << firama_isimi;
                            cout << endl << "firma tel no:" << firma_tel_no;

                            cout << endl << "firma sorumlusu" << firma_Sorumlusu;
                            cout << endl << "m��teri katagorisi (genel/�zel):" << musteri_katagorisi;
                            cout << endl << "adres:" << adres_bilgileri;
                        }
                        else {
                            Dosyayaz5 << firma_no << ' ' << firama_isimi << ' ' << firma_tel_no << ' ' << firma_Sorumlusu << ' ' << musteri_katagorisi << ' ' << adres_bilgileri << endl;
                        }

                    }

                    Dosyayaz5.close();
                    Dosyaoku5.close();
                    remove("cari.txt");
                    rename("yeni_cari.txt", "cari.txt");

                }
            } while (musteri_islmeleri_Secimi != 5);

        }
        else if (genel_secim == 3) //S�PAR�� ��LEMLER�:::genel se�imde 3 e basarsan�z m��teri k�sm� a��l�r vealt men�deki i�lemler yap�l�r.
        {

            int siparis_islmeleri_secimi = 0;

            do {
                cout << endl << endl << "siperi� i�lemerli....." << endl << "yapmak istediginiz islemi seciniz:";
                cout << endl << endl << "sipari� olu�turmak i�in 1:" << endl << "sipari� aramak i�in 2:" << endl <<
                    "sipari� silmek i�in 3:" << endl << "sipari� d�zeltmek i�in 4:" << endl <<
                    "sipari� raporlama i�in 5: " << endl << "Ana men�ye donus icin 6:" << endl;

                cin >> siparis_islmeleri_secimi;
                cout << endl;

                int satir_Sayisi_Siparis = 0;
                if (siparis_islmeleri_secimi == 1) //S�PAR�� EKLEMEK ::: //siprari� nuamars� eklentisi ile t�m i�ler sipari� nuamrs�n� baz alarak yap�l�yor...
                //ve sipari� numar�s� al�rken tekillilk kontrolu yap�l�yor...
                {
                    int musteri_no_gecici;;
                    int musteri_no_kontrol_siparis_icin = 0;

                    int siparis_no_gecici;

                    ifstream dosya_oku_siparis_musteri("cari.txt");
                    ofstream doyyayaz_siparis_bilgileri;
                    ifstream dosya_oku_tekillik_siparis("siparis_bilgileri.txt");
                    ifstream dosyaoku_kontrol_siparis("siparis_bilgileri.txt");

                    doyyayaz_siparis_bilgileri.open("siparis_bilgileri.txt", ios::app);
                    int gecici_fiyat = 0;

                    cout << "eklmek istediginiz sipari�e yeni bir siparis kodu giriniz:" << endl;
                    cin >> siparis_no_gecici;
                    siparis_no = siparis_no_gecici;
                    while (dosyaoku_kontrol_siparis >> siparis_no >> firma_no >> siparis_tarihi >> siparis_tutari >> urun_kodu >> siparis_Adedi >> siparisi_alan) {
                        satir_Sayisi_Siparis++;
                    }
                    if (satir_Sayisi_Siparis == 0)
                        //satir sayisinin kontrolunden olu�an sonuca g�re ekleme i�lemi yap�l�yor...
                    {
                        //m��teri no isteniyor...
                        cout << "musteri no girimiz";
                        cin >> musteri_no_gecici;
                        while (dosya_oku_siparis_musteri >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {
                            ifstream dosyaoku_siparis_urun_bilgileri("urun_bilgileri.txt");
                            ifstream dosyaoku_siparis_urun_bilgileri2("urun_bilgileri.txt");
                            ofstream dosyayaz_Siparis_listesi_dosyasi("xyz.txt", ios::app);
                            ifstream dosyaoku_fiyaticin("urun_bilgileri.txt");
                            ifstream dosyaoku_siparis_no_icin("siparis_bilgileri.txt");

                            if (musteri_no_gecici == firma_no) {
                                musteri_no_kontrol_siparis_icin = 1;

                                if (musteri_katagorisi == "genel") {
                                    while (dosyaoku_siparis_urun_bilgileri >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                        cout << endl << "urun kodu:" << urun_kodu << endl;
                                        cout << "urun adi:" << urun_ad� << endl;
                                        cout << "urun �reticisi:" << urunun_ureticisi << endl;
                                        cout << "fiyat:" << fiyat << endl;

                                    }

                                    cout << endl << endl << endl << "eklemk istediginiz �r�n�n kodunu giriniz:";
                                    cin >> urun_kodu_siparis;
                                    urun_kodu = urun_kodu_siparis;
                                    while (dosyaoku_fiyaticin >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                        if (urun_kodu_siparis == urun_kodu) {
                                            gecici_fiyat = fiyat;
                                        }
                                    }
                                    siparis_no = siparis_no_gecici;
                                    cout << endl << "adet giriniz:";
                                    cin >> siparis_Adedi;
                                    dosyayaz_Siparis_listesi_dosyasi << siparis_no << ' ' << urun_kodu_siparis << ' ' << siparis_Adedi << endl;
                                    cout << endl << "sipari� tarihi" << endl;
                                    cin >> siparis_tarihi;

                                    siparis_tutari = siparis_Adedi * gecici_fiyat;
                                    cout << "sipari� tutari:" << siparis_tutari << endl;
                                    cout << "sipari�i alan: ";
                                    cin >> siparisi_alan;
                                    firma_no = musteri_no_gecici;
                                    doyyayaz_siparis_bilgileri << siparis_no << ' ' << firma_no << ' ' << siparis_tarihi << ' ' << siparis_tutari << ' ' << urun_kodu << ' ' << siparis_Adedi << ' ' << siparisi_alan << endl;

                                }
                                else if (musteri_katagorisi == "ozel") {
                                    siparis_no = siparis_no_gecici;
                                    while (dosyaoku_siparis_urun_bilgileri2 >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                        cout << endl << "urun kodu:" << urun_kodu << endl;
                                        cout << "urun adi:" << urun_ad� << endl;
                                        cout << "urun �reticisi:" << urunun_ureticisi << endl;
                                        cout << "fiyat:" << ozel_fiyat << endl;
                                    }

                                    cout << endl << endl << endl << "eklemk istediginiz �r�n�n kodunu giriniz:";
                                    cin >> urun_kodu_siparis;
                                    while (dosyaoku_fiyaticin >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                        if (urun_kodu_siparis == urun_kodu) {
                                            gecici_fiyat = ozel_fiyat;
                                        }
                                    }
                                    cout << endl << "adet giriniz:";
                                    cin >> siparis_Adedi;

                                    dosyayaz_Siparis_listesi_dosyasi << siparis_no << ' ' << urun_kodu_siparis << ' ' << siparis_Adedi << endl;
                                    cout << "sipari� tarihi" << endl;
                                    cin >> siparis_tarihi;
                                    cout << "sipari� tutari:" << siparis_Adedi * ozel_fiyat;
                                    siparis_tutari = siparis_Adedi * gecici_fiyat;
                                    cout << endl << "sipari�i alan: ";
                                    cin >> siparisi_alan;

                                    doyyayaz_siparis_bilgileri << siparis_no << ' ' << firma_no << ' ' << siparis_tarihi << ' ' << siparis_tutari << ' ' << urun_kodu << ' ' << siparis_Adedi << ' ' << siparisi_alan << endl;

                                    dosyaoku_siparis_urun_bilgileri.close();
                                    dosyaoku_siparis_urun_bilgileri2.close();
                                    dosyayaz_Siparis_listesi_dosyasi.close();

                                }

                            }

                        }

                    }
                    //sat�r sayisinin 0' dan farkl� durumlar� g�z �n�ne al�n�yor. ve e�le�en bi sipari� no varsa uyar� veriyor...
                    else if (satir_Sayisi_Siparis != 0) {
                        int kontrol_sipris = 1;
                        while (dosya_oku_tekillik_siparis >> siparis_no >> firma_no >> siparis_tarihi >> siparis_tutari >> urun_kodu >> siparis_Adedi >> siparisi_alan) {
                            if (siparis_no = siparis_no_gecici == siparis_no) {
                                kontrol_sipris = 0;
                                cout << "l�tfen ba�ka bir sipari� no giriniz...";
                                musteri_no_kontrol_siparis_icin = 1;
                            }
                        }

                        if (kontrol_sipris == 1) {
                            cout << "musteri no girimiz";
                            cin >> musteri_no_gecici;
                            while (dosya_oku_siparis_musteri >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {
                                ifstream dosyaoku_siparis_urun_bilgileri("urun_bilgileri.txt");
                                ifstream dosyaoku_siparis_urun_bilgileri2("urun_bilgileri.txt");
                                ofstream dosyayaz_Siparis_listesi_dosyasi("xyz.txt", ios::app);
                                ifstream dosyaoku_fiyaticin("urun_bilgileri.txt");
                                ifstream dosyaoku_siparis_no_icin("siparis_bilgileri.txt");

                                if (musteri_no_gecici == firma_no) {
                                    musteri_no_kontrol_siparis_icin = 1;

                                    if (musteri_katagorisi == "genel") {
                                        while (dosyaoku_siparis_urun_bilgileri >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                            cout << endl << "urun kodu:" << urun_kodu << endl;
                                            cout << "urun adi:" << urun_ad� << endl;
                                            cout << "urun �reticisi:" << urunun_ureticisi << endl;
                                            cout << "fiyat:" << fiyat << endl;

                                        }

                                        cout << endl << endl << endl << "eklemk istediginiz �r�n�n kodunu giriniz:";
                                        cin >> urun_kodu_siparis;
                                        urun_kodu = urun_kodu_siparis;
                                        while (dosyaoku_fiyaticin >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                            if (urun_kodu_siparis == urun_kodu) {
                                                gecici_fiyat = fiyat;
                                            }
                                        }
                                        siparis_no = siparis_no_gecici;
                                        cout << endl << "adet giriniz:";
                                        cin >> siparis_Adedi;
                                        dosyayaz_Siparis_listesi_dosyasi << siparis_no << ' ' << urun_kodu_siparis << ' ' << siparis_Adedi << endl;
                                        cout << endl << "sipari� tarihi" << endl;
                                        cin >> siparis_tarihi;

                                        siparis_tutari = siparis_Adedi * gecici_fiyat;
                                        cout << "sipari� tutari:" << siparis_tutari << endl;
                                        cout << "sipari�i alan: ";
                                        cin >> siparisi_alan;
                                        musteri_no_gecici = firma_no;
                                        doyyayaz_siparis_bilgileri << siparis_no << ' ' << firma_no << ' ' << siparis_tarihi << ' ' << siparis_tutari << ' ' << urun_kodu << ' ' << siparis_Adedi << ' ' << siparisi_alan << endl;

                                    }
                                    else if (musteri_katagorisi == "ozel") {
                                        siparis_no = siparis_no_gecici;
                                        while (dosyaoku_siparis_urun_bilgileri2 >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                            cout << endl << "urun kodu:" << urun_kodu << endl;
                                            cout << "urun adi:" << urun_ad� << endl;
                                            cout << "urun �reticisi:" << urunun_ureticisi << endl;
                                            cout << "fiyat:" << ozel_fiyat << endl;
                                        }

                                        cout << endl << endl << endl << "eklemk istediginiz �r�n�n kodunu giriniz:";
                                        cin >> urun_kodu_siparis;
                                        while (dosyaoku_fiyaticin >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                            if (urun_kodu_siparis == urun_kodu) {
                                                gecici_fiyat = ozel_fiyat;
                                            }
                                        }
                                        cout << endl << "adet giriniz:";
                                        cin >> siparis_Adedi;

                                        dosyayaz_Siparis_listesi_dosyasi << siparis_no << ' ' << urun_kodu_siparis << ' ' << siparis_Adedi << endl;
                                        cout << "sipari� tarihi" << endl;
                                        cin >> siparis_tarihi;
                                        cout << "sipari� tutari:" << siparis_Adedi * ozel_fiyat;
                                        siparis_tutari = siparis_Adedi * gecici_fiyat;
                                        cout << endl << "sipari�i alan: ";
                                        cin >> siparisi_alan;

                                        doyyayaz_siparis_bilgileri << siparis_no << ' ' << firma_no << ' ' << siparis_tarihi << ' ' << siparis_tutari << ' ' << urun_kodu << ' ' << siparis_Adedi << ' ' << siparisi_alan << endl;

                                        dosyaoku_siparis_urun_bilgileri.close();
                                        dosyaoku_siparis_urun_bilgileri2.close();
                                        dosyayaz_Siparis_listesi_dosyasi.close();

                                    }

                                }

                            }
                        }

                    }

                    if (musteri_no_kontrol_siparis_icin == 0) {
                        cout << endl << "b�yle bir m��teri bulunmamaktad�r.." << endl;
                    }

                }
                else if (siparis_islmeleri_secimi == 2) //S�PAR�� ARAMA::
             //sipari� aramada kullan�cdan aranan sipari� no girilmesi isteniyor.... ve e�le�en veriler ekrana ��kt� olarak veriliyor...
                {

                    int aranan_siparis_no;
                    int kontrol_for_siparis_arama_varmi = 0;
                    cout << "l�tfen aramak istediginiz siparisin kodunu giriniz:";
                    cin >> aranan_siparis_no;
                    ifstream siparis_arama("siparis_bilgileri.txt");
                    while (siparis_arama >> siparis_no >> firma_no >> siparis_tarihi >> siparis_tutari >> urun_kodu >> siparis_Adedi >> siparisi_alan) {
                        if (aranan_siparis_no == siparis_no) {
                            cout << "aranan siparis bilgileri..." << endl;
                            cout << "siparis no:" << siparis_no <<
                                endl << "firma no:" << firma_no <<
                                endl << "siparis tarihi" << siparis_tarihi <<
                                endl << "sipari� tutar�:" << siparis_tutari <<
                                endl << "urunun kodu:" << urun_kodu <<
                                endl << "siparis adedi:" << siparis_Adedi <<
                                endl << "siprasi alan ki�i:" << siparisi_alan;
                            cout << endl;

                            kontrol_for_siparis_arama_varmi = 1;

                        }
                    }
                    siparis_arama.close();

                    if (kontrol_for_siparis_arama_varmi == 0) {
                        cout << endl << "BU NO YA SAH�P B�R S�PAR�S BULUNMAMAKTAD�R...";
                    }

                    kontrol_for_siparis_arama_varmi = 0;
                }
                else if (siparis_islmeleri_secimi == 3) //siparis silme //Var olan dosaydan veriler okunur ve silmek istenen kod d���ndaki veriler ba�ka bir dosayaya aktar�l�r ve 
             //dosya silinir yeni olu�turulan dosyada ismini eski dosaya �evirtilir...
                {
                    int siapris_silme_aranan_siparis_no;
                    cout << "silmek istediginiz siparis nosunu giriniz:";
                    cin >> siapris_silme_aranan_siparis_no;
                    ifstream dosyaoku_sipraris_silme("siparis_bilgileri.txt");
                    ofstream dosyayaz_siparis_silmee("gecici_siparis.tmp", ios::app);
                    ofstream dosyayaz_xyz_silme("xyz_gecici.tmp", ios::app);
                    ifstream dosyaoku_xyz_silme("xyz.txt");

                    while (dosyaoku_xyz_silme >> siparis_no >> urun_kodu_siparis >> siparis_Adedi) {
                        if (siapris_silme_aranan_siparis_no == siparis_no) {
                            cout << "burdas�n";
                        }
                        else if (siapris_silme_aranan_siparis_no != siparis_no) {
                            dosyayaz_xyz_silme << siparis_no << ' ' << urun_kodu_siparis << ' ' << siparis_Adedi << endl;
                        }
                    }
                    dosyayaz_xyz_silme.close();
                    dosyaoku_xyz_silme.close();
                    remove("xyz.txt");
                    rename("xyz_gecici.tmp", "xyz.txt");

                    while (dosyaoku_sipraris_silme >> siparis_no >> firma_no >> siparis_tarihi >> siparis_tutari >> urun_kodu >> siparis_Adedi >> siparisi_alan) {
                        if (siapris_silme_aranan_siparis_no == siparis_no) {
                            cout << "silincek siparisin bilgileri..." << endl <<
                                "sipari� no:" << siparis_no << endl <<
                                "firma no:" << siparis_no << endl <<
                                "sipari� tarihi:" << siparis_tarihi << endl <<
                                "siparsi tutatr�:" << siparis_tutari << endl <<
                                "urun_kodu:" << urun_kodu << endl <<
                                "sipars adedi:" << siparis_Adedi << endl <<
                                "siparisi alan:" << siparisi_alan << endl;
                        }
                        else if (siapris_silme_aranan_siparis_no != siparis_no) {
                            dosyayaz_siparis_silmee << siparis_no << ' ' << firma_no << ' ' << siparis_tarihi << ' ' << siparis_tutari << ' ' << urun_kodu << ' ' << siparis_Adedi << ' ' << siparisi_alan << endl;
                        }
                    }
                    dosyaoku_sipraris_silme.close();
                    dosyayaz_siparis_silmee.close();

                    remove("siparis_bilgileri.txt");
                    rename("gecici_siparis.tmp", "siparis_bilgileri.txt");

                }
                else if (siparis_islmeleri_secimi == 4) //sipari� d�zeltme... //ayn� �ekilde sipari� silmedeki gibi i�leyi� var fakat silinicek olan sipari� kodunun oldugu blokta yeni degerler al�n�yor ve dosayaya yaz�l�yor....
                {
                    int siparis_no_geici;

                    ifstream dosya_oku_siparis_d�uzeltme("siparis_bilgileri.txt");
                    ifstream dosyaoku_genel_ozel;
                    ifstream dosyaoku_sipris_duzeltme;

                    int duzltme_siparis_no;
                    cout << "L�tfen d�zeltmek istedi�iniz sipari� nosunu giriniz:";
                    cin >> duzltme_siparis_no;
                    dosyaoku_genel_ozel.open("cari.txt");
                    int firma_no_gecici_siparis_genel_ozel;
                    ifstream dosyaoku_sipris_icin_urun_bilgileri_duzeltme;
                    dosyaoku_sipris_icin_urun_bilgileri_duzeltme.open("urun_bilgileri.txt");
                    string musteri_katogorisi_siparis_duzeltme;
                    int duzeltme_siparis_urun_kodu;
                    ofstream dosyaa_yazxyz;
                    ifstream dosya_oku_urunler_siparis_duzeltme_kayit;
                    while (dosya_oku_siparis_d�uzeltme >> siparis_no >> firma_no >> siparis_tarihi >> siparis_tutari >> urun_kodu >> siparis_Adedi >> siparisi_alan) {
                        if (duzltme_siparis_no == siparis_no) {
                            cout << "G�NCELENECEK S�PAR�S B�LG�LER�...";

                            cout << "sipari� no:" << siparis_no << endl <<
                                "firma no:" << firma_no << endl <<
                                "sipari� tarihi:" << siparis_tarihi << endl <<
                                "siparsi tutatr�:" << siparis_tutari << endl <<
                                "urun_kodu:" << urun_kodu << endl <<
                                "sipars adedi:" << siparis_Adedi << endl <<
                                "siparisi alan:" << siparisi_alan << endl;

                            cout << "g�ncelemee...";

                            cout << "yeni sipari� no giriniz:";
                            cin >> siparis_no_geici;
                            cout << "firma no giriniz:";
                            cin >> firma_no;
                            firma_no_gecici_siparis_genel_ozel = firma_no;

                            while (dosyaoku_genel_ozel >> firma_no >> firama_isimi >> firma_tel_no >> firma_Sorumlusu >> musteri_katagorisi >> adres_bilgileri) {
                                if (firma_no_gecici_siparis_genel_ozel == firma_no) {
                                    musteri_katogorisi_siparis_duzeltme = musteri_katagorisi;
                                }
                            }
                            dosyaoku_genel_ozel.close();
                            while (dosyaoku_sipris_icin_urun_bilgileri_duzeltme >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                if (musteri_katogorisi_siparis_duzeltme == "genel") {
                                    cout << endl << "urun kodu:" << urun_kodu << endl;
                                    cout << "urun adi:" << urun_ad� << endl;
                                    cout << "urun �reticisi:" << urunun_ureticisi << endl;
                                    cout << "fiyat:" << fiyat << endl;

                                }
                                else if (musteri_katogorisi_siparis_duzeltme == "ozel") {

                                    cout << endl << "urun kodu:" << urun_kodu << endl;
                                    cout << "urun adi:" << urun_ad� << endl;
                                    cout << "urun �reticisi:" << urunun_ureticisi << endl;
                                    cout << "fiyat:" << fiyat << endl;

                                }

                            }
                            dosyaoku_sipris_icin_urun_bilgileri_duzeltme.close();

                            cout << endl << endl << endl << "l�tfen almak istediginiz �r�n kodunu giriniz:";
                            cin >> duzeltme_siparis_urun_kodu;

                            ifstream dosya_oku_urunler_siparis_duzeltme_kayit;
                            dosya_oku_urunler_siparis_duzeltme_kayit.open("urun_bilgileri.txt");
                            ofstream siparis_bilgileri_duzeltmer;
                            ofstream xyz_yaz_duzeltme;

                            siparis_bilgileri_duzeltmer.open("siparis_bilgileri_gecicii.txt", ios::app);

                            while (dosya_oku_urunler_siparis_duzeltme_kayit >> urun_kodu >> urun_ad� >> urunun_ureticisi >> temin_suresi >> uretim_tarih >> fiyat >> ozel_fiyat >> kdv_orani >> stok_adedi) {
                                if (duzeltme_siparis_urun_kodu == urun_kodu) {
                                    if (musteri_katogorisi_siparis_duzeltme == musteri_katagorisi) {
                                        cout << "siparis tarihi girinz:";
                                        cin >> siparis_tarihi;
                                        cout << "adet girinz:";
                                        cin >> siparis_Adedi;
                                        cout << "siparisi alaN:";
                                        cin >> siparisi_alan;
                                        if (musteri_katogorisi_siparis_duzeltme == "genel") {
                                            siparis_tutari = fiyat * siparis_Adedi;
                                        }
                                        cout << endl << "yeni siparis tutar�:" << siparis_tutari;
                                        siparis_no = siparis_no_geici;
                                        firma_no = firma_no_gecici_siparis_genel_ozel;
                                        urun_kodu = duzeltme_siparis_urun_kodu;
                                        //     xyz_yaz_duzeltme.open("xyz_geciiii.txt", ios::app);
                                        //   xyz_yaz_duzeltme << siparis_no << ' ' << urun_kodu << ' ' << siparis_Adedi << endl;
                                        //    xyz_yaz_duzeltme.close();

                                        siparis_bilgileri_duzeltmer << siparis_no << ' ' << firma_no << ' ' << siparis_tarihi << ' ' << siparis_tutari << ' ' << urun_kodu << ' ' << siparis_Adedi << ' ' << siparisi_alan << endl;
                                    }

                                }

                            }

                            siparis_bilgileri_duzeltmer.close();
                            dosya_oku_urunler_siparis_duzeltme_kayit.close();

                        }
                        else {
                            ofstream dosyayaz_siparis_duzetlme;
                            dosyayaz_siparis_duzetlme.open("siparis_bilgileri_gecicii.txt", ios::app);
                            dosyayaz_siparis_duzetlme << siparis_no << ' ' << firma_no << ' ' << siparis_tarihi << ' ' << siparis_tutari << ' ' << urun_kodu << ' ' << siparis_Adedi << ' ' << siparisi_alan << endl;
                            dosyayaz_siparis_duzetlme.close();

                            dosyaa_yazxyz.open("xyz_geciiii.txt", ios::app);

                            urun_kodu_siparis = urun_kodu;
                            //    dosyaa_yazxyz << siparis_no << ' ' << urun_kodu_siparis << ' ' << siparis_Adedi << endl;
                            //      dosyaa_yazxyz.close();

                        }
                        //       remove("xyz.txt");

                        //          rename("xyz_geciiii", "xyz.txt");

                    }

                    dosya_oku_siparis_d�uzeltme.close();

                    remove("siparis_bilgileri.txt");
                    rename("siparis_bilgileri_gecicii.txt", "siparis_bilgileri.txt");

                }

                //     rename("xyz_geciiii", "xyz.txt");
                else if (siparis_islmeleri_secimi == 5) {
                    ifstream siparis_arama2("siparis_bilgileri.txt");
                    cout << "    :::S�PAR�� B�LG�LER�:::";
                    while (siparis_arama2 >> siparis_no >> firma_no >> siparis_tarihi >> siparis_tutari >> urun_kodu >> siparis_Adedi >> siparisi_alan) {

                        cout << endl << endl;

                        cout << "siparis no:" << siparis_no <<
                            endl << "firma no:" << firma_no <<
                            endl << "siparis tarihi" << siparis_tarihi <<
                            endl << "sipari� tutar�:" << siparis_tutari <<
                            endl << "urunun kodu:" << urun_kodu <<
                            endl << "siparis adedi:" << siparis_Adedi <<
                            endl << "siprasi alan ki�i:" << siparisi_alan;
                        cout << endl;

                    }

                }

            } while (siparis_islmeleri_secimi != 6);

        }

    } while (genel_secim != 4);

    return 0;
}